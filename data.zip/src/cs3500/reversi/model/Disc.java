package cs3500.reversi.model;

/**
 * Represents a disc in a Reversi game, distinguished by its color.
 */
public enum Disc {
  BLACK, WHITE;
}
